//
//  AIRGoogleMapCalloutSubview.m
//  AirMaps
//
//  Created by Denis Oblogin on 10/8/18.
//
//

#ifdef HAVE_GOOGLE_MAPS

#import "AIRGoogleMapCalloutSubview.h"
#import <React/RCTUtils.h>
#import <React/RCTView.h>
#import <React/RCTBridge.h>

@implementation AIRGoogleMapCalloutSubview
@end

#endif
