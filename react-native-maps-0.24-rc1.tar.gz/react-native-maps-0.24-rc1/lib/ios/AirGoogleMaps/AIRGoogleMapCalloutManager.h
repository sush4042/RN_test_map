//
//  AIRGoogleMapCalloutManager.h
//  AirMaps
//
//  Created by Gil Birman on 9/6/16.
//
//

#ifdef HAVE_GOOGLE_MAPS

#import <React/RCTViewManager.h>

@interface AIRGoogleMapCalloutManager : RCTViewManager

@end

#endif
