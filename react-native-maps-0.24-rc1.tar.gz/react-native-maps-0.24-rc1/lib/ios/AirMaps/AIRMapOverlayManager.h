#import <React/RCTViewManager.h>

@interface AIRMapOverlayManager : RCTViewManager

@end
